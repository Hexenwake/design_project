import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {

  late String _email;
  late String _password;

  Future<void> _createUser() async {
    try{
      UserCredential userCredential = await FirebaseAuth
          .instance
          .createUserWithEmailAndPassword(email: _email, password: _password);
      print("user: $userCredential");
    }on FirebaseAuthException catch (e) {
      //print("Error: $e");
    }catch (e){
      //_error = "Error: $e";
      print("Error: $e");
    }
  }

  Future<void> _login() async {
    try{
      UserCredential userCredential = await FirebaseAuth
          .instance
          .signInWithEmailAndPassword(email: _email, password: _password);
      print("user: $userCredential");
    }on FirebaseAuthException catch (e) {
      //print("Error: $e");
    }catch (e){
      print("Error: $e");
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              onChanged: (value){
                _email = value;
              },
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                hintText: "Enter Email..."
              ),
            ),
            TextField(
              obscureText: true,
              onChanged: (value){
                _password = value;
              },
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                hintText: "Enter Password.."
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(),
              margin: EdgeInsets.symmetric(),
              color: Colors.grey,

            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                RaisedButton(
                    onPressed: _login,
                  child: Text("Login"),
                ),
                RaisedButton(
                  onPressed: _createUser,
                  child: Text("Create New Account"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
