package com.example.design_project_loginpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
